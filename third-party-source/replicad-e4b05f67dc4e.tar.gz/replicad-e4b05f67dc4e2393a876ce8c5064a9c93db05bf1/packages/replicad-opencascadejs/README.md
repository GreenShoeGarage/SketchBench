# `replicad-opencascadejs`

An opencascadejs build containing only the APIs necessary to run replicad. You
will need to have docker installed, as well as ytt (in order to generate the
configuration files).

## Usage

```
npm run build
```

You need to have a docker instance running and have run
`docker pull donalffons/opencascade.js`
