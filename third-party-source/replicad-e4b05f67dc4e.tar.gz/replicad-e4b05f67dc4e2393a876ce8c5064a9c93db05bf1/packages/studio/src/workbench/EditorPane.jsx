import React from "react";
import debounce from "debounce";
import styled from "styled-components";
import { observer } from "mobx-react";
import Editor from "@monaco-editor/react";

import replicadTypes from "replicad/types?raw";
import replicadShapeFnsTypes from "replicad/shape-functions/types?raw";

import Splitter, { GutterTheme, SplitDirection } from "@devbookhq/splitter";

import "./loadMonaco";
import useEditorStore from "../visualiser/editor/useEditorStore";
import downloadCode from "../utils/downloadCode";
import { HeaderButton, HeaderSelect } from "./panes";
import Download from "../icons/Download";
import Share from "../icons/Share";
import LoadingScreen from "../components/LoadingScreen";
import { LinkEditor } from "../components/LinkEditor";

import { Dialog, DialogTitle, DialogBody } from "../components/Dialog.jsx";
import { useAutoload } from "./Autoload";
import Reload from "../icons/Reload";

export const ErrorOverlay = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 100%;
  gap: 0.4em;
  padding: 2em;
  border-color: red;
  border-width: 2px;
  max-height: initial;
  max-width: 50vw;
  max-height: 90vw;

  & > :first-child {
    color: red;
  }

  & > :nth-child(2) {
    font-size: 1.2em;
  }

  & > pre {
    font-size: 0.6em;
    overflow-x: auto;
    padding: 1em;
    color: #444;
    background-color: #f2e0de;
  }
`;

const WarningOverlay = styled(ErrorOverlay)`
  border-color: #d28b00;

  & > :first-child {
    color: #d28b00;
  }
`;

export default observer(function EditorPane() {
  const store = useEditorStore();
  const editorRef = React.useRef(null);
  const monacoRef = React.useRef(null);

  const language = store.code.language;

  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor;
    monacoRef.current = monaco;

    const extraLibs = [
      {
        content: `declare module 'replicad' { ${replicadTypes} }`,
      },
      {
        content: `declare module 'replicad/shape-functions' { ${replicadShapeFnsTypes} }`,
      },
      {
        content: `
  import * as replicadAll from 'replicad';
  import * as replicadShapeFnsAll from 'replicad/shape-functions';
  declare global {
  declare var replicad = replicadAll;
  declare var replicadShapeFns = replicadShapeFnsAll;
  }
`,
      },
    ];

    const diagnosticsOptions = {
      // 2307: "Cannot find module" - suppress for URL imports handled at runtime
      diagnosticCodesToIgnore: [2792],
    };

    monaco.languages.typescript.javascriptDefaults.setEagerModelSync(true);
    monaco.languages.typescript.javascriptDefaults.setExtraLibs(extraLibs);
    monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions(
      diagnosticsOptions
    );

    monaco.languages.typescript.typescriptDefaults.setEagerModelSync(true);
    monaco.languages.typescript.typescriptDefaults.setExtraLibs(extraLibs);
    monaco.languages.typescript.typescriptDefaults.setDiagnosticsOptions(
      diagnosticsOptions
    );
  };

  React.useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) return;
    const model = editor.getModel();
    if (model) {
      monaco.editor.setModelLanguage(model, language);
    }
  }, [language]);

  if (!store.code.initialized) return <LoadingScreen />;

  return (
    <>
      <Splitter
        direction={SplitDirection.Vertical}
        gutterTheme={GutterTheme.Dark}
        gutterClassName="custom-gutter-theme"
        initialSizes={
          store.error || store.compatibilityWarning ? [75, 25] : [100]
        }
      >
        <Editor
          defaultLanguage={language}
          defaultValue={store.code.current}
          theme="vs-dark"
          height="100%"
          onChange={debounce((e) => {
            store.code.update(e, true);
          }, 300)}
          onMount={handleEditorDidMount}
          options={{
            automaticLayout: true,
            minimap: { enabled: false },
          }}
        />
        {store.error ? (
          <ErrorOverlay>
            <div>Error</div>
            <div>{store.error?.message}</div>
            {store.error.stack && <pre>{store.error.stack}</pre>}
            {store.compatibilityWarning && (
              <div>{store.compatibilityWarning}</div>
            )}
          </ErrorOverlay>
        ) : store.compatibilityWarning ? (
          <WarningOverlay>
            <div>Compatibility warning</div>
            <div>{store.compatibilityWarning}</div>
          </WarningOverlay>
        ) : null}
      </Splitter>
    </>
  );
});

const ShareDialog = observer(({ onClose }) => {
  const store = useEditorStore();

  return (
    <Dialog onClose={onClose}>
      <DialogTitle onClose={onClose}>Your shareable links</DialogTitle>
      <DialogBody>
        <div style={{ maxWidth: "60vw" }}>
          <LinkEditor fromCode={store.code.current} />
        </div>
      </DialogBody>
    </Dialog>
  );
});

const Spacer = styled.div`
  flex: 1;
`;

export const EditorButtons = observer(() => {
  const store = useEditorStore();
  const [share, setShare] = React.useState(false);

  const toggleAutoload = useAutoload();

  const download = () => {
    const shapeName =
      store.currentMesh.length === 1 ? store.currentMesh[0]?.name : null;
    return downloadCode(store.code.current, shapeName);
  };

  const filePickerSupported = window.showOpenFilePicker !== undefined;

  return (
    <>
      <HeaderSelect
        value={store.code.language}
        onChange={(e) => store.code.setLanguage(e.target.value)}
        title="Editor language"
      >
        <option value="javascript">js</option>
        <option value="typescript">ts</option>
      </HeaderSelect>

      {filePickerSupported && (
        <>
          <HeaderButton onClick={toggleAutoload} title="Toggle autoreload">
            <Reload />
          </HeaderButton>
          <Spacer />
        </>
      )}

      <HeaderButton onClick={() => setShare(true)} title="Share">
        <Share />
      </HeaderButton>
      <HeaderButton onClick={download} title="Download">
        <Download />
      </HeaderButton>
      {share && <ShareDialog onClose={() => setShare(false)} />}
    </>
  );
});
